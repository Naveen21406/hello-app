const amountInput = document.getElementById('amount');
const fromCurrency = document.getElementById('fromCurrency');
const toCurrency = document.getElementById('toCurrency');
const convertBtn = document.getElementById('convertBtn');
const resultDiv = document.getElementById('result');

// Hardcoded exchange rates relative to USD
const rates = {
    USD: 1,
    INR: 83.5,
    EUR: 0.93,
    GBP: 0.81,
    JPY: 146
};

convertBtn.addEventListener('click', () => {
    const amount = parseFloat(amountInput.value);
    const from = fromCurrency.value;
    const to = toCurrency.value;

    if (isNaN(amount)) {
        alert('Please enter a valid amount');
        return;
    }

    // Convert amount to USD first, then to target currency
    const amountInUSD = amount / rates[from];
    const convertedAmount = amountInUSD * rates[to];

    resultDiv.textContent = `${amount} ${from} = ${convertedAmount.toFixed(2)} ${to}`;
});
